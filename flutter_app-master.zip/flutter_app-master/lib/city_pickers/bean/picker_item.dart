class PickerItem {
  String name;
  dynamic value;

  PickerItem({this.name, this.value});
}
