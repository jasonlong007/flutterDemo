class Question {
  final String question;
  final bool answer;

  Question(this.question, this.answer);
}
