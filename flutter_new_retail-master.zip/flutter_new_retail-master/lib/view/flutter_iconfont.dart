library flutter_iconfont;

import 'package:flutter/widgets.dart' show IconData;
import 'package:flutter_yjh/view/flutter_icon_data.dart';

///
/// This is an automatically generated code
///author: arcticfox1919
///github: https://github.com/arcticfox1919/flutter_iconfont
///
class IconFonts{
  IconFonts._();

  static const IconData triangle_down = const IconDataEx(0xe6b4);
  static const IconData eye = const IconDataEx(0xe616);
  static const IconData scan_code = const IconDataEx(0xe640);
  static const IconData triangle_right = const IconDataEx(0xe615);
  static const IconData arrow_down = const IconDataEx(0xe62a);
  static const IconData arrow_left = const IconDataEx(0xe62c);
  static const IconData shopping_cart = const IconDataEx(0xe614);
  static const IconData ellipsis = const IconDataEx(0xe727);
  static const IconData location = const IconDataEx(0xe612);
  static const IconData arrow_right = const IconDataEx(0xe620);
  static const IconData eye_close = const IconDataEx(0xe50e);
}
